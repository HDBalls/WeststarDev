# -*- coding: utf-8 -*-

from . import vehicles
from . import project
from . import vehicle_services
from . import res_partner
# from . import product
